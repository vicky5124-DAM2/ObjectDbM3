package pe1.uf6.m3.dam2;

public class Main {
    public static void main(String[] args) throws Exception {
        new AppMoodle().start(args);
    }
}
